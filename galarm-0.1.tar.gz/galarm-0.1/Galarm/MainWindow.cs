using System;
using System.Diagnostics;
using System.Timers;
using Gtk;
using Gdk;

public partial class MainWindow: Gtk.Window
{
	Galarm.UserAlarms alarms;
	private Boolean create = false;
	private int comboBoxNumEntries = 1;

	public MainWindow (Galarm.UserAlarms alarms): base (Gtk.WindowType.Toplevel)
	{
		this.alarms = alarms;		
		Build ();
		
		dayControlsVisible(false);
		alarmSettingsVisible(false);	
		
		FileFilter filter1 = new FileFilter();
		filter1.Name = "Audio Files";
		filter1.AddPattern("*.mp3");
		filter1.AddPattern("*.wav");
		filter1.AddPattern("*.ogg");
		filter1.AddPattern("*.flac");
				
		FileFilter filter2 = new FileFilter();
		filter2.Name = "Audio Playlists";
		filter2.AddPattern("*.m3u");
		filter2.AddPattern("*.pls");
		
		this.filechooserbutton1.AddFilter(filter1);
		this.filechooserbutton1.AddFilter(filter2);
		loadAlarms();
	}
	
	private void alarmSettingsVisible(Boolean vis)
	{				
		hbox12.Visible = vis;
		hbox13.Visible = vis;
		vbox14.Visible = vis;		
		hbox2.Visible = vis;
		hbox3.Visible = vis;
		hbox4.Visible = vis;
		hbox5.Visible = vis;
		hbox6.Visible = vis;
		hbox7.Visible = vis;
		hseparator3.Visible = vis;	
		hseparator2.Visible = vis;
		hseparator1.Visible = vis;
		hseparator4.Visible = vis;
		
		if(vis==false)
			this.Resize(420,55);
		else
			this.Resize(420,226);
	}
		
	private void dayControlsVisible(Boolean vis)
	{				
		checkbutton11.Visible = vis;
		checkbutton12.Visible = vis;
		checkbutton13.Visible = vis;
		checkbutton15.Visible = vis;
		checkbutton16.Visible = vis;
		checkbutton17.Visible = vis;
		checkbutton18.Visible = vis;	
		vbox10.Visible = vis;
		vbox11.Visible = vis;
		vbox12.Visible = vis;
		vbox13.Visible = vis;
		hbox14.Visible = vis;
		hbox1.Visible = vis;
		hseparator3.Visible = vis;
		
		if(vis==false)
			this.Resize(420,226);
		else
			this.Resize(420,310);
	}	
			
	private void loadAlarms()
	{	
		if(this.comboBoxNumEntries>1)
		{
			for(int h=this.comboBoxNumEntries; h > 0; h--)
			{
				this.combobox3.RemoveText(h);				
			}
			this.comboBoxNumEntries = 1;
		}
		
		String[] savedAlarms = this.alarms.getAlarms();	
		int numAlarms = this.alarms.getNumAlarms();
		String[] details;
		
		int y;
				
		try
		{		
			for (y=0; y < numAlarms; y++)
			{							
				details = savedAlarms[y].Split(',');
					
				String name = details[0];
				int Ahour = int.Parse(details[1]);
				int Amin = int.Parse(details[2]);
				int Asec = int.Parse(details[3]);
				int mon = int.Parse(details[4]);
				int tue = int.Parse(details[5]);
				int wed = int.Parse(details[6]);
				int thur = int.Parse(details[7]);
				int fri = int.Parse(details[8]);
				int sat = int.Parse(details[9]);
				int sun = int.Parse(details[10]);
				
				int days = 0;
				
				String dayShow = "";
						
				if(mon==1)
				{
					days++;
					dayShow += "M,";
				}
				if(tue==1)
				{
					days++;		
					dayShow += "Tue,";
				}
				if(wed==1)
				{
					days++;
					dayShow += "W,";
				}
				if(thur==1)
				{
					days++;	
					dayShow += "Thur,";
				}
				if(fri==1)
				{
					days++;
					dayShow += "F,";
				}
				if(sat==1)
				{
					days++;	
					dayShow += "Sat,";
				}
				if(sun==1)
				{
					days++;		
					dayShow += "Sun";
				}
				
				
				if(days==7)
					dayShow = "Everyday";

				String entry = name + " - " + Ahour + ":" + Amin + ":" + Asec + " - ( " + dayShow + " )";	
				this.combobox3.AppendText(entry);	
				this.comboBoxNumEntries++;
			}
		}
		catch(Exception e)
		{
			Console.WriteLine(e.StackTrace.ToString());	
		}
		
		this.combobox3.Active = 0;
	}
	
	public void addAlarm()
	{
		this.alarms.add(this.entry1.Text,(int)this.spinbutton7.Value,(int)this.spinbutton6.Value,(int)this.spinbutton5.Value,this.checkbutton11.Active,this.checkbutton12.Active,this.checkbutton13.Active,this.checkbutton18.Active,this.checkbutton15.Active,this.checkbutton16.Active,this.checkbutton17.Active,this.checkbutton9.Active,this.filechooserbutton2.Filename.ToString(),this.filechooserbutton1.Filename.ToString(),(int)this.hscale2.Value);
		this.loadAlarms();
	}
	
	public void updateAlarm()
	{
		int index = combobox3.Active - 1;
		this.alarms.update(index,this.entry1.Text,(int)this.spinbutton7.Value,(int)this.spinbutton6.Value,(int)this.spinbutton5.Value,this.checkbutton11.Active,this.checkbutton12.Active,this.checkbutton13.Active,this.checkbutton18.Active,this.checkbutton15.Active,this.checkbutton16.Active,this.checkbutton17.Active,this.checkbutton9.Active,this.filechooserbutton2.Filename.ToString(),this.filechooserbutton1.Filename.ToString(),(int)this.hscale2.Value);
		this.loadAlarms();
	}
	
	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{		
		this.Destroy();
	}

	protected virtual void OnCheckbutton10Clicked (object sender, System.EventArgs e)
	{
		if(checkbutton10.Active==true)
		{
			this.checkbutton11.Active = true;
			this.checkbutton12.Active = true;
			this.checkbutton13.Active = true;
			this.checkbutton15.Active = true;
			this.checkbutton16.Active = true;
			this.checkbutton17.Active = true;
			this.checkbutton18.Active = true;
			dayControlsVisible(false);			
		}
		else
		{
			dayControlsVisible(true);
		}
	}
	
	protected virtual void OnButton3Clicked (object sender, System.EventArgs e)
	{
		if(button3.Label == "Set Alarm")
		{			
			this.button4.Visible = false;
			this.button3.Label = "Create new";
			dayControlsVisible(false);
			alarmSettingsVisible(false);	
			
			if(this.create==true)
			{
				addAlarm();
				this.create = false;
			}
			else
			{
				updateAlarm();
			}			
		}
		else
		{		
			this.create = true;
			checkbutton10.Active = true;
			checkbutton9.Active = true;
			this.button4.Visible = true;
			this.button3.Label = "Set Alarm";
			dayControlsVisible(false);
			alarmSettingsVisible(true);			
			//this.entry3.Text = "";
		}
	}

	protected virtual void OnButton4Clicked (object sender, System.EventArgs e)
	{
		this.button3.Label = "Create new";
		this.button4.Visible = false;
		dayControlsVisible(false);
		alarmSettingsVisible(false);	
		this.combobox3.Active = 0;
		this.create = false;
	}
	
	protected virtual void OnCombobox3Changed (object sender, System.EventArgs e)
	{				
		int index = this.combobox3.Active -1;
		
		if(index<=-1)
		{
			this.button4.Visible = false;
			this.button3.Label = "Create new";
			dayControlsVisible(false);
			alarmSettingsVisible(false);
			this.create = false;
			return;
		}
		
		String alarm = this.alarms.getAlarm(index);
		String[] details = alarm.Split(',');
					
		String name = details[0];
		int Ahour = int.Parse(details[1]);
		int Amin = int.Parse(details[2]);
		int Asec = int.Parse(details[3]);
		int mon = int.Parse(details[4]);
		int tue = int.Parse(details[5]);
		int wed = int.Parse(details[6]);
		int thur = int.Parse(details[7]);
		int fri = int.Parse(details[8]);
		int sat = int.Parse(details[9]);
		int sun = int.Parse(details[10]);
		int active = int.Parse(details[11]);
		String command = details[12];		
		String argument = details[13];
		int vol = int.Parse(details[14]);
		
		this.filechooserbutton2.SetFilename(command);
		this.filechooserbutton1.SetFilename(argument);		
		this.hscale2.Value = vol;
				
		
		this.checkbutton11.Active = false;
		this.checkbutton12.Active = false;
		this.checkbutton13.Active = false;
		this.checkbutton15.Active = false;
		this.checkbutton16.Active = false;
		this.checkbutton17.Active = false;
		this.checkbutton18.Active = false;
				
		this.entry1.Text = name;
		this.spinbutton7.Value = Ahour;
		this.spinbutton6.Value = Amin;
		this.spinbutton5.Value = Asec;
		
		int days = 0;
		
		if(mon==1)
		{
			this.checkbutton11.Active = true;
			days++;
		}
		if(tue==1)
		{
			this.checkbutton12.Active = true;
			days++;
		}
		if(wed==1)
		{
			this.checkbutton13.Active = true;
			days++;
		}
		if(thur==1)
		{
			this.checkbutton18.Active = true;
			days++;
		}
		if(fri==1)
		{
			this.checkbutton15.Active = true;
			days++;
		}
		if(sat==1)
		{
			this.checkbutton16.Active = true;
			days++;
		}
		if(sun==1)
		{
			this.checkbutton17.Active = true;
			days++;
		}
		
		
		alarmSettingsVisible(true);
		this.button4.Visible = true;
		this.button3.Label = "Set Alarm";
		
		if(active==1)
			this.checkbutton9.Active = 	true;
		else
			this.checkbutton9.Active = 	false;
		
		if(days==7)
		{
			checkbutton10.Active = true;
			dayControlsVisible(false);
		}
		else
		{
			checkbutton10.Active = false;
			dayControlsVisible(true);
		}
				
	}
	
}
