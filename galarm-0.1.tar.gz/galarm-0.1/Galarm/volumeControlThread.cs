using System;
using System.Diagnostics;
using System.Threading;

namespace Galarm
{	
	
	public class volumeControlThread
	{
		private int volume = 0;
		
		public volumeControlThread(int vol)
		{
			this.volume = vol;			
		}
		
		public void adjustVolume()
		{
			int p = 1000;
			String command = "amixer";
			String argument = " -D hw:0 -q sset Master Playback Volume 50% unmute";
			
			Process unmute = new Process();
			unmute.StartInfo.FileName = command;
			unmute.StartInfo.Arguments = argument;
			unmute.StartInfo.UseShellExecute = true;
			unmute.Start();	
			
			for (int i=this.volume; i < 101; i++)
        	{
				argument = " -D hw:0 -q sset Master Playback Volume " +  i + "%";
				
				Process increaseVol = new Process();
				increaseVol.StartInfo.FileName = command;
				increaseVol.StartInfo.Arguments = argument;
				increaseVol.StartInfo.UseShellExecute = true;
				increaseVol.Start();	
							
            	Thread.Sleep(p);
				p = p + 1000;
        	}

		}
	}
}
