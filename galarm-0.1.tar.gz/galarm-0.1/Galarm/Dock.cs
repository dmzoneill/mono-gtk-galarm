using System;
using System.Diagnostics;
using System.Timers;
using System.Threading;
using Gtk;
using Gdk;


public partial class Dock : Gtk.Window
{
		
	StatusIcon  myStatusIcon;
	public static Galarm.UserAlarms alarms = new Galarm.UserAlarms();
	private ThreadStart job;
	private Thread jobRunner;
		
	public Dock() : base(Gtk.WindowType.Toplevel)
	{
		myStatusIcon = new StatusIcon(new Gdk.Pixbuf("/home/dave/projects/Galarm/Galarm/bin/Release/icon2.png"));
		myStatusIcon.Tooltip = "Right click for menu";
		myStatusIcon.Visible = true;
		myStatusIcon.PopupMenu += OnStatusIconPopupMenu;
			

		System.Timers.Timer myTimer = new System.Timers.Timer();
	   	myTimer.Elapsed += new ElapsedEventHandler( checkAlarms );
		myTimer.Interval = 800;
		myTimer.Start();
						
		this.Build();
	}
		
	
	protected void OnStatusIconPopupMenu(object sender, EventArgs e)
	{
		Menu popupMenu = new Menu();
			
		ImageMenuItem alarmItem = new ImageMenuItem("Alarm Settings");
		alarmItem.Image = new Gtk.Image("/home/dave/projects/Galarm/Galarm/bin/Release/icon2-small.png");
		alarmItem.Show();
		alarmItem.Activated += new EventHandler(OnShowEvent);
		popupMenu.Append(alarmItem);		
		
		ImageMenuItem quitItem = new ImageMenuItem("Quit");
		quitItem.Image = new Gtk.Image(Stock.Quit);
		quitItem.Show();
		quitItem.Activated += new EventHandler(OnUserDestroyEvent);
		popupMenu.Append(quitItem);		
		
		popupMenu.Popup(null,null,null,3,Gtk.Global.CurrentEventTime);
	}
		
		
	protected void OnShowEvent (object sender, EventArgs e )
	{			
		MainWindow win = new MainWindow (Dock.alarms);
		win.Move(Screen.Width - 430, 40);
		win.Show ();
	}
		
		
	protected void checkAlarms( object source, ElapsedEventArgs e )
	{										
		String[] savedAlarms = Dock.alarms.getAlarms();	
		int numAlarms = Dock.alarms.getNumAlarms();
		String[] details;
		
		int y;
				
		try
		{		
			for (y=0; y < numAlarms; y++)
			{							
				details = savedAlarms[y].Split(',');
					
				int Ahour = int.Parse(details[1]);
				int Amin = int.Parse(details[2]);
				int Asec = int.Parse(details[3]);
				int mon = int.Parse(details[4]);
				int tue = int.Parse(details[5]);
				int wed = int.Parse(details[6]);
				int thur = int.Parse(details[7]);
				int fri = int.Parse(details[8]);
				int sat = int.Parse(details[9]);
				int sun = int.Parse(details[10]);
				int act = int.Parse(details[11]);
				String program = details[12];
				String argument = details[13];
				int vol = int.Parse(details[14]);
				
				String today = DateTime.Now.DayOfWeek.ToString();
				
				int tMon = 0;
				int tTue = 0;
				int tWed = 0;
				int tThur = 0;
				int tFri = 0;
				int tSat = 0;
				int tSun = 0;
				
				
				if(today == "Monday")
					tMon = 1;
				if(today == "Tuesday")
					tTue = 1;
				if(today == "Wednesday")
					tWed = 1;
				if(today == "Thursday")
					tThur = 1;
				if(today == "Friday")
					tFri = 1;
				if(today == "Saturday")
					tSat = 1;
				if(today == "Sunday")
					tSun = 1;
				
				
				if(act == 1)
				{
					if(DateTime.Now.Second == Asec && DateTime.Now.Minute == Amin && DateTime.Now.Hour == Ahour)
					{
						if((mon + tMon == 2) || (tue + tTue == 2) || (wed + tWed == 2) || (thur + tThur == 2) || (fri + tFri == 2) || (sat + tSat == 2) || (sun + tSun == 2))
						{
							Galarm.volumeControlThread volumeControl = new Galarm.volumeControlThread(vol);
														
							// alarm stuff
							Process alarmTime = new Process();
							alarmTime.StartInfo.FileName = program;
							alarmTime.StartInfo.Arguments = argument;
							alarmTime.StartInfo.UseShellExecute = true;
							alarmTime.Start();					
							
							try
							{
								this.job = new ThreadStart(volumeControl.adjustVolume);
        						this.jobRunner = new Thread(this.job);
        						this.jobRunner.Start();							
							}
							catch(Exception k)
							{
								k.StackTrace.ToString();	
							}
						}
					}
				}
								
			}
		}
		catch(Exception p)
		{
			Console.WriteLine(p.StackTrace.ToString());	
		}
	}
		
		
	protected void OnUserDestroyEvent(object sender, EventArgs a)
	{
		this.jobRunner.Abort();
		Application.Quit ();
	}
	
}
