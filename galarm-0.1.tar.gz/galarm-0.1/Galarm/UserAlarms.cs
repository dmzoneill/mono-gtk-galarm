using System;

namespace Galarm
{	
	public class UserAlarms
	{		
		
		private String[] alarms = new String[100];
		private int numAlarms = 0;
		
		public UserAlarms()
		{
			/*
			Random rand = new Random();
			int y;
		
			for (y=0; y<20; y++)
			{			
				int Asec = rand.Next(0,59);
				int Amin = rand.Next(0,59);
				int Ahour = rand.Next(0,23);
				int mon = rand.Next(0,2);
				int tue = rand.Next(02);
				int wed = rand.Next(0,2);
				int thur = rand.Next(0,2);
				int fri = rand.Next(0,2);
				int sat = rand.Next(0,2);
				int sun = rand.Next(0,2);
				int act = rand.Next(0,2);
				alarms[numAlarms] = "Alarm," + Ahour + "," + Amin + "," + Asec + "," + mon + "," + tue + "," + wed + "," + thur + "," + fri + "," + sat + "," + sun + "," + act + ",/usr/bin/vlc,/home/dave/alarm.mp3,50";	
				numAlarms++;
			}		
			
			alarms[numAlarms] = "Alarm," + 5 + "," + 18 + "," + 3 + "," + 1 + "," + 1 + "," + 1 + "," + 1 + "," + 1 + "," + 1 + "," + 1 + "," + 1 + ",/usr/bin/vlc,/home/dave/alarm.mp3,50";	
			numAlarms++;
			*/
		}
		
		
		public String[] getAlarms()
		{
			return this.alarms;	
		}
		
		
		public int getNumAlarms()
		{
			return this.numAlarms;	
		}
		
		
		public String getAlarm(int id)
		{
			return alarms[id];
		}
		
		
		public void add(String name, int hour, int min, int sec, bool mon, bool tue, bool wed, bool thur, bool fri, bool sat, bool sun, bool act, String player, String argument, int vol)
		{
			int dmon = 0;
			int dtue = 0; 
			int dwed = 0; 
			int dthur = 0; 
			int dfri = 0; 
			int dsat = 0; 
			int dsun = 0; 					
			int dact = 0;
			
			if(mon)	dmon = 1;
			if(tue)	dtue = 1;
			if(wed)	dwed = 1;
			if(thur)dthur = 1;
			if(fri)	dfri = 1;
			if(sat)	dsat = 1;
			if(sun)	dsun = 1;
			if(act)	dact = 1;			
			
			this.alarms[numAlarms] = name + "," + hour + "," + min + "," + sec + "," + dmon + "," + dtue + "," + dwed + "," + dthur+ "," + dfri + "," + dsat + "," + dsun + "," + dact + "," + player + "," + argument + "," +vol;
			this.numAlarms++;
		}
		
		
		public void update(int index, String name, int hour, int min, int sec, bool mon, bool tue, bool wed, bool thur, bool fri, bool sat, bool sun, bool act, String player, String argument, int vol)
		{
			int dmon = 0;
			int dtue = 0; 
			int dwed = 0; 
			int dthur = 0; 
			int dfri = 0; 
			int dsat = 0; 
			int dsun = 0; 					
			int dact = 0;
			
			if(mon)	dmon = 1;
			if(tue)	dtue = 1;
			if(wed)	dwed = 1;
			if(thur)dthur = 1;
			if(fri)	dfri = 1;
			if(sat)	dsat = 1;
			if(sun)	dsun = 1;
			if(act)	dact = 1;			
			
			this.alarms[index] = name + "," + hour + "," + min + "," + sec + "," + dmon + "," + dtue + "," + dwed + "," + dthur+ "," + dfri + "," + dsat + "," + dsun + "," + dact + "," + player + "," + argument + "," +vol;
		}
		
	}
}
