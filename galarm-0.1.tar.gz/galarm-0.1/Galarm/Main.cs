using System;
using Gtk;

namespace Galarm
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Application.Init ();
			Dock alarm = new Dock ();
			alarm.Show ();
			Application.Run ();
		}
	}
}